Locales['en'] = {

  ['skin_menu'] = 'Karaktär Utstyrsel',
  ['use_rotate_view'] = 'använd ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ och ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ för att snurra runt din karaktär.',
  ['skin'] = 'Byt utseende',
  ['saveskin'] = 'save skin to a file',

}
