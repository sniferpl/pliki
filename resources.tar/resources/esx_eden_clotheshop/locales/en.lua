Locales['en'] = {
	['valid_this_purchase'] = 'Bạn có muốn mua không?',
  	['yes_valid_purchase'] = 'Mua <span style="color: green;">$%s</span>',
	['yes'] = 'Có',
	['no'] = 'Không',
	['name_outfit'] = 'Tên Trang Phục?',
	['not_enough_money'] = 'Bạn không đủ tiền',
	['press_menu'] = 'Bam ~INPUT_CONTEXT~ de mo menu',
	['clothes'] = 'CUA HANG QUAN AO',
	['you_paid'] = 'Ban mua ~g~$',
	['save_in_dressing'] = 'Bạn có muốn lưu lại trang phục không?',
	['shop_clothes'] = 'Cửa hàng quần áo',
	['player_clothes'] = 'Phòng thay đồ',
	['shop_main_menu'] = 'Xin chào',
	['saved_outfit'] = 'Lưu lại đồ đã mua',
	['loaded_outfit'] = 'Bạn đã chọn lại đồ đã mua',
	['suppr_cloth'] = 'Xóa quần áo đã lưu ',
	['supprimed_cloth'] = 'Quần áo lưa đã được xóa'
}
