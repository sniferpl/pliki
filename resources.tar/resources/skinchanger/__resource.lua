description 'Skin Changer'

version '1.0.1'

client_scripts {
  'locale.lua',
  'locales/de.lua',
  'locales/en.lua',
  'locales/fr.lua',
  'config.lua',
  'client/main.lua'
}
